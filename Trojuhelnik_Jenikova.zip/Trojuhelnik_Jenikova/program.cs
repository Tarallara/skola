﻿using System;

namespace trojuhelniky
{
    class Program
    {
        static void Main(string[] args)
        {
            float a;
            float b;
            float c;

            bool CanConvert;
            trojuhelnik t;

            Console.WriteLine("zadejte prosim 3 strany trojuhelniku: ");
            do
            {
                Console.WriteLine("a: ");
                CanConvert = float.TryParse(Console.ReadLine(), out a);
                while (a < 0)
                {
                    Console.WriteLine("zadejte prosim kladne cislo");
                    Console.WriteLine("a: ");
                    CanConvert = float.TryParse(Console.ReadLine(), out a);

                }
            } while (CanConvert == false);
            do
            {
                Console.WriteLine("b: ");
                CanConvert = float.TryParse(Console.ReadLine(), out b);
                while (b < 0)
                {
                    Console.WriteLine("zadejte prosim kladne cislo");
                    Console.WriteLine("b: ");
                    CanConvert = float.TryParse(Console.ReadLine(), out b);

                }
            } while (CanConvert == false);

            do
            {
                Console.WriteLine("c: ");
                CanConvert = float.TryParse(Console.ReadLine(), out c);
                while (a < 0)
                {
                    Console.WriteLine("zadejte prosim kladne cislo");
                    Console.WriteLine("c: ");
                    CanConvert = float.TryParse(Console.ReadLine(), out c);

                }
            } while (CanConvert == false);

            t = new trojuhelnik(a, b, c);

            bool exists;

            exists = t.CanExist();
            

            while (exists == false);
            {
                Console.WriteLine("Trojuhelnik nelze sestrojit, zadejte vsechny strany znovu (vsechny), nebo jenom jednu ([a, b. c])");
                string what = Console.ReadLine();
                if (what == "a")
                {
                    do
                    {
                        Console.WriteLine("a: ");
                        CanConvert = float.TryParse(Console.ReadLine(), out a);
                        while (a < 0)
                        {
                            Console.WriteLine("a: ");
                            CanConvert = float.TryParse(Console.ReadLine(), out a);
                        }
                    } while (CanConvert == false);

                    t.SetA(a);
                    exists = t.CanExist();
                }
                if (what == "b")
                {
                    do
                    {
                        Console.WriteLine("b: ");
                        CanConvert = float.TryParse(Console.ReadLine(), out b);
                        while (a < 0)
                        {
                            Console.WriteLine("b: ");
                            CanConvert = float.TryParse(Console.ReadLine(), out b);
                        }
                    } while (CanConvert == false);

                    t.SetA(b);
                    exists = t.CanExist();
                }
                if (what == "a")
                {
                    do
                    {
                        Console.WriteLine("c: ");
                        CanConvert = float.TryParse(Console.ReadLine(), out c);
                        while (a < 0)
                        {
                            Console.WriteLine("c: ");
                            CanConvert = float.TryParse(Console.ReadLine(), out c);
                        }
                    } while (CanConvert == false);

                    t.SetA(c);
                    exists = t.CanExist();
                }
                if (what == "vsechny")
                {
                    Console.WriteLine("Zadejte strany znovu prosim");
                    do
                    {
                        Console.WriteLine("a: ");
                        CanConvert = float.TryParse(Console.ReadLine(), out a);
                        while (a < 0)
                        {
                            Console.WriteLine("a: ");
                            CanConvert = float.TryParse(Console.ReadLine(), out a);
                        }
                    } while (CanConvert == false);

                    do
                    {
                        Console.WriteLine("b: ");
                        CanConvert = float.TryParse(Console.ReadLine(), out b);
                        while (b < 0)
                        {
                            Console.WriteLine("b: ");
                            CanConvert = float.TryParse(Console.ReadLine(), out b);
                        }
                    } while (CanConvert == false);

                    do
                    {
                        Console.WriteLine("c: ");
                        CanConvert = float.TryParse(Console.ReadLine(), out c);
                        while (c < 0)
                        {
                            Console.WriteLine("c: ");
                            CanConvert = float.TryParse(Console.ReadLine(), out c);
                        }
                    } while (CanConvert == false);

                    t.SetStr(a, b, c);
                    exists = t.CanExist();
                }
            }

            exists = t.CanExist();
            Console.WriteLine("Lze trojúhelník sestroji - " + exists);

            bool loop = true;
            do
            {
                Console.WriteLine(" preje te si: ");
                Console.WriteLine(" 0 - ukoncit rogram");
                Console.WriteLine(" 1a - zmenit stranu a");
                Console.WriteLine(" 1b- zmenit stranu b");
                Console.WriteLine(" 1c- zmenit stranu c");
                Console.WriteLine(" 1-  prepsat vsechny strany");
                Console.WriteLine(" 2a- vypsat tranu a");
                Console.WriteLine(" 2b - vypsat tranu b");
                Console.WriteLine(" 2c - vypsat tranu c");
                Console.WriteLine(" 2 - vypsat vsechny strany");
                Console.WriteLine(" 3 - vypsat uhly");


                string action;
                action = Console.ReadLine();

                if (action == "0")
                {
                    Console.WriteLine("preji krasny den");
                    loop = false;
                }

                if (action == "1a")
                {
                    do
                    {
                        do
                        {
                            Console.WriteLine("a: ");
                            CanConvert = float.TryParse(Console.ReadLine(), out a);
                            while (a < 0)
                            {
                                Console.WriteLine("a: ");
                                CanConvert = float.TryParse(Console.ReadLine(), out a);
                            }
                        } while (CanConvert == false);

                        t.SetA(a);
                        exists = t.CanExist();

                        if (exists == false)
                            Console.WriteLine("Trojúhelník po změně nejde sestrojit, zkuste to znovu.");

                    } while (exists != true);

                }
                if (action == "1b")
                {
                    do
                    {
                        do
                        {
                            Console.WriteLine("b: ");
                            CanConvert = float.TryParse(Console.ReadLine(), out b);
                            while (b < 0)
                            {
                                Console.WriteLine("b: ");
                                CanConvert = float.TryParse(Console.ReadLine(), out b);
                            }
                        } while (CanConvert == false);

                        t.SetB(b);
                        exists = t.CanExist();

                        if (exists == false)
                            Console.WriteLine("Trojúhelník po změně nejde sestrojit, zkuste to znovu.");

                    } while (exists != true);

                }

                if (action == "1c")
                {
                    do
                    {
                        do
                        {
                            Console.WriteLine("c: ");
                            CanConvert = float.TryParse(Console.ReadLine(), out c);
                            while (c < 0)
                            {
                                Console.WriteLine("c: ");
                                CanConvert = float.TryParse(Console.ReadLine(), out c);
                            }
                        } while (CanConvert == false);

                        t.SetC(c);
                        exists = t.CanExist();

                        if (exists == false)
                            Console.WriteLine("Trojúhelník po změně nejde sestrojit, zkuste to znovu.");

                    } while (exists != true);
                }
                if (action == "2a")
                {
                    Console.WriteLine(t.GetA());
                }

                if (action == "2b")
                {
                    Console.WriteLine(t.GetB());
                }

                if (action == "2c")
                {
                    Console.WriteLine(t.GetC());
                }
                if (action == "1")
                {
                    do
                    {
                        Console.WriteLine("Zadejte svoje 3 strany");
                        do
                        {
                            Console.WriteLine("a: ");
                            CanConvert = float.TryParse(Console.ReadLine(), out a);
                            while (a < 0)
                            {
                                Console.WriteLine("a: ");
                                CanConvert = float.TryParse(Console.ReadLine(), out a);
                            }
                        } while (CanConvert == false);

                        do
                        {
                            Console.WriteLine("b: ");
                            CanConvert = float.TryParse(Console.ReadLine(), out b);
                            while (b < 0)
                            {
                                Console.WriteLine("b: ");
                                CanConvert = float.TryParse(Console.ReadLine(), out b);
                            }
                        } while (CanConvert == false);

                        do
                        {
                            Console.WriteLine("c: ");
                            CanConvert = float.TryParse(Console.ReadLine(), out c);
                            while (c < 0)
                            {
                                Console.WriteLine("c: ");
                                CanConvert = float.TryParse(Console.ReadLine(), out c);
                            }
                        } while (CanConvert == false);

                        t.SetStr(a, b, c);
                        exists = t.CanExist();

                        if (exists == false)
                            Console.WriteLine("Zadanej trojúhelník nelze sestrojit, zadejte hodnoty znova.");

                    } while (exists != true);

                }
                if (action == "2")
                {
                    Console.WriteLine("a: " + t.GetA() + ", b: " + t.GetB() + ", c: " + t.GetC());
                }

                if (action == "3")
                {
                    Console.WriteLine("Uhel u strany A: " + t.GetAlpha());
                    Console.WriteLine("Uhel u strany B: " + t.GetBeta());
                    Console.WriteLine("Uhel u strany C: " + t.GetGamma());
                }



            } while (loop == true);

        }
    }
}
